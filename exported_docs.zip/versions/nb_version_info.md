---
weight: 0
title: Version Info
---
# Version Info
version=5.17.0-SNAPSHOT
groupId=io.nosqlbench
artifactId=nbr
